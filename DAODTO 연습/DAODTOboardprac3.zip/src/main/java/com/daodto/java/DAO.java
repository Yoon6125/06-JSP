package com.daodto.java;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class DAO extends DA {
	// 1.글 목록
	public ArrayList<DTO> list(String pageNum) {
		ArrayList<DTO> post = new ArrayList<DTO>();

		int startindex = ((Integer.parseInt(pageNum) - 1) * 3);
		connect();
		String sql = String.format("select * from PS_BOARD_FREE limit %d,3", startindex);
		try {

			ResultSet rs = st.executeQuery(sql);
			while (rs.next()) {
				post.add(new DTO(rs.getString("b_no"), rs.getString("b_title"), rs.getString("b_id"),
						rs.getString("b_datetime"), rs.getString("b_hit")));
			}
			closeconnect();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return post;
	}

	// 2.글 보기
	public DTO read(String no) {
		DTO post = null;
		connect();
		String sql = String.format("select * from PS_BOARD_FREE where b_no ='%s'", no);
		try {
			ResultSet rs = st.executeQuery(sql);
			while (rs.next()) {
				post = new DTO(rs.getString("b_no"), rs.getString("b_title"), rs.getString("b_id"),
						rs.getString("b_datetime"), rs.getString("b_hit"), rs.getString("b_text"),
						rs.getString("b_reply_count"), rs.getString("b_reply_ori"));
			}
			closeconnect();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return post;
	}

	// 3.글 쓰기
	public void write(DTO d) {
		connect();
		String sql = String.format(
				"insert into PS_BOARD_FREE (b_title,b_id, b_text, b_datetime) values('%s','%s','%s', now())", d.title,
				d.id, d.text);
		updateQuerysql(sql);
		closeconnect();

	}

	// 4.글 삭제

	public void delete(String no) {
		connect();
		String sql = String.format("delete from PS_BOARD_FREE where b_no='%s'", no);
		updateQuerysql(sql);
		closeconnect();
	}

	// 5.글 수정

	// 6.전체 글 수 및 페이징

	public int getCountnum() {
		int count = 0;

		connect();
		String sql = "select count(*) from PS_BOARD_FREE";
		ResultSet rs;
		try {
			rs = st.executeQuery(sql);
			while (rs.next()) {
				count = rs.getInt("count(*)");
			}
			closeconnect();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return count;
	}
}
