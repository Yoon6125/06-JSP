package com.daodto.java;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class DAO {
	Connection con = null;
	Statement st = null;

	// 1.글 리스트
	public ArrayList<DTO> list() {
		ArrayList<DTO> post = new ArrayList<DTO>();

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/my_cat", "root", "root");
			st = con.createStatement();

			String sql = "select * from javasqlboard";

			ResultSet rs = st.executeQuery(sql);

			while (rs.next()) {
				post.add(new DTO(rs.getString("num"), rs.getString("title"), rs.getString("id"),
						rs.getString("date_time")));
			}
			st.close();
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return post;
	}

	// 2.글 읽기

	public DTO read(String a) {
		DTO post = null;

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/my_cat", "root", "root");
			st = con.createStatement();

			String sql = String.format("select * from javasqlboard where num='%s'", a);

			ResultSet rs = st.executeQuery(sql);

			while (rs.next()) {
				post = new DTO(rs.getString("num"), rs.getString("title"), rs.getString("content"), rs.getString("id"),
						rs.getString("date_time"));
			}
			st.close();
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return post;
	}

	// 3.글 쓰기

	public void write(DTO d) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/my_cat", "root", "root");
			st = con.createStatement();

			String sql = String.format("insert into javasqlboard values(0,'%s','%s','%s',now())", d.title, d.content,
					d.id);

			int result = st.executeUpdate(sql);

			System.out.println("실행된 쿼리:" + sql);
			System.out.println("실행된 행 수:" + result);

			st.close();
			con.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// 4.글 지우기

	public void delete(String a) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/my_cat", "root", "root");
			st = con.createStatement();

			String sql = String.format("delete from javasqlboard where num='%s'", a);

			int result = st.executeUpdate(sql);

			System.out.println("실행된 쿼리:" + sql);
			System.out.println("실행된 행 수:" + result);

			st.close();
			con.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// 5.글 수정하기

	public void edit(DTO d, String a) {

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/my_cat", "root", "root");
			st = con.createStatement();
			String sql = String.format(
					"update javasqlboard set title='%s' , content='%s', id='%s' , date_time =now() where num='%s' ",
					d.title, d.content, d.id, a);

			int result = st.executeUpdate(sql);
			System.out.println("실행된 쿼리:" + sql);
			System.out.println("실행된 행 수:" + result);

			st.close();
			con.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
