package com.daodto.java;

public class DTO {
	public String no;
	public String title;
	public String content;
	public String id;
	public String date_time;

	public DTO(String no, String title, String content, String id, String date_time) {
		this.no = no;
		this.title = title;
		this.content = content;
		this.id = id;
		this.date_time = date_time;
	}

	public DTO(String title, String content, String id) {
		this.title = title;
		this.content = content;
		this.id = id;
	}

	public DTO(String no, String title, String id, String date_time) {
		this.no = no;
		this.title = title;
		this.id = id;
		this.date_time = date_time;
	}

}
