package com.daodto1.java;

public class DTO {
	public String no;
	public String title;
	public String id;
	public String text;
	public String datetime;
	public String hit;
	public String reply_count;
	public String reply_ori;

	public DTO(String no, String title, String id, String text, String datetime, String hit, String reply_count,
			String reply_ori) {
		this.no = no;
		this.title = title;
		this.id = id;
		this.text = text;
		this.datetime = datetime;
		this.hit = hit;
		this.reply_count = reply_count;
		this.reply_ori = reply_ori;
	}

	public DTO(String no, String title, String id, String datetime, String hit) {
		super();
		this.no = no;
		this.title = title;
		this.id = id;
		this.datetime = datetime;
		this.hit = hit;
	}

	public DTO(String title, String id, String text) {
		this.title = title;
		this.id = id;
		this.text = text;
	}

}
