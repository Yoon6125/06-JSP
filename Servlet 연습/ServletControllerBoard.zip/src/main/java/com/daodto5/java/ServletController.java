package com.daodto5.java;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/board/*")
public class ServletController extends HttpServlet {
	String nextPage;
	DAO dao;

	@Override
	public void init() throws ServletException {
		dao = new DAO();
	}

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String action = req.getPathInfo();
		System.out.println("action:" + action);

		if (action != null) {
			switch (action) {
			case "/delete":
				System.out.println("삭제");
				nextPage = "/list.jsp";
				dao.delete(req.getParameter("no"));
				break;
			case "/write":
				System.out.println("쓰기");
				nextPage = "/write.jsp";
				dao.write(new DTO(req.getParameter("title"), req.getParameter("id"), req.getParameter("text")));
				break;
			case "/read":
				System.out.println("읽기");
				nextPage = "/read.jsp";
				DTO d = dao.read(req.getParameter("no"));
				req.setAttribute("post", d);
				break;
			case "/list":
				System.out.println("리스트");
				nextPage = "/list.jsp";
				break;
			default:
				break;
			}
		}
		RequestDispatcher d = req.getRequestDispatcher(nextPage);
		d.forward(req, resp);

	}
}
