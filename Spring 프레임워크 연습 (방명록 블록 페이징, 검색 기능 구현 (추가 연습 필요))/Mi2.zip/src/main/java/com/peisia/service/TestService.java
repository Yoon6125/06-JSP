package com.peisia.service;

public interface TestService {
	public String getOne();

	public String getTwo();

	public void updateVisitCount();

	public void insertDoodle();

	public void delTest();
}
