package com.peisia.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.peisia.service.TestService;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Log4j
@RequestMapping("/test/*")
//@AllArgsConstructor
@Controller
public class TestController {

	@Setter(onMethod_ = @Autowired)
	private TestService service;

	@GetMapping("/getOnePlusTwo")
	public void getOnePlusTwo(Model model) {
		// public void getOnePlusTwo() {
		log.info("getOnePlusTwo===========================");
		String one = service.getOne();
		String two = service.getTwo();

		Integer sum = Integer.parseInt(one) + Integer.parseInt(two);

		log.info("(컨트롤러 테스트)1 더하기 2는 =" + sum);
	}

	@GetMapping("/updateVisitCount")
	public void updateVisitCount() {
		service.updateVisitCount();
		log.info("(컨트롤러) 메서드 실행 완료, 쿼리 업데이트");
	}

	@GetMapping("/insertDoodle")
	public void insertDoodle() {
		service.insertDoodle();
		log.info("(컨트롤러) 메서드 실행 완료, 쿼리 업데이트");
	}

	@GetMapping("/delTest")
	public void delTest() {
		service.delTest();
		log.info("(컨트롤러) 메서드 실행 완료, 쿼리 업데이트");
	}
}
