<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<c:set var="cp" value="${pageContext.request.contextPath}" /><!-- el변수 cp에 경로저장 -->
<%@page import="com.peisia.dto.GuestDto"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<link rel="stylesheet" href="${cp }/resources/common.css" >
<title>Insert title here</title>
</head>
<body>
<%
	Object o= request.getAttribute("read");
	GuestDto d = (GuestDto)o;
	
	long bno = d.getBno();
	String btext = d.getBtext();
%>
<%=bno %><br>
<%=btext %>
<hr>

<a href="${cp }/guest/del?bno=<%=bno %>">글 삭제</a>
<a href="${cp }/guest/modify?bno=<%=bno %>">글 수정</a>
</body>
</html>