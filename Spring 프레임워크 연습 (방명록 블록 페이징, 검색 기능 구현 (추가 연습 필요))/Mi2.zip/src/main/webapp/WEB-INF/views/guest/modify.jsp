<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<c:set var="cp" value="${pageContext.request.contextPath}" /><!-- el변수 cp에 경로저장 -->
<%@page import="com.peisia.dto.GuestDto"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<link rel="stylesheet" href="${cp }/resources/common.css" >
<title>Insert title here</title>
</head>
<body>
<%
	GuestDto read = (GuestDto)request.getAttribute("modify_read");

	long bno = read.getBno();
	String btext = read.getBtext();
%>

글번호: <%=bno %><br>
글 내용: 
	<form action="${cp}/guest/modify" method="post">
		<input type="hidden" name="bno" value ='<%=bno %>'>
		<textarea name="btext">
			<%=btext %>
		</textarea>
		<input type="submit" value="수정하기">
	</form>
</body>
</html>