<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core"%>
<c:set var="cp" value="${pageContext.request.contextPath}" />
<!-- el변수 cp에 경로저장 -->
<%@page import="com.peisia.dto.GuestDto"%>
<%@page import="java.util.List"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>방명록 - 글 목록</title>
<link rel="stylesheet" href="${cp}/resources/common.css">
</head>
<body>
	<h1>방명록</h1>
	<h2>글목록</h2>
	총 글 수 :${count} , 총 페이지 수 :${totalPageCount} , 블럭 당 페이지 수:
	${pagesPerBlock} , 현재 블럭: ${currentBlock}
	<br> 블럭 시작 페이지: ${blockStartPage} , 블럭 끝 페이지: ${blockEndPage} , 블럭
	총 수 : ${blockCount}
	<br> 이전 블럭 가능: ${hasBlockPrev} , 다음 블럭 가능: ${hasBlockNext}
	<hr>
	<table>
		<tr>
			<td>번호</td>
			<td>내용</td>
		</tr>
		<c:set var="arr" value="${Serchlist}" />

		<c:forEach var="i" items="${arr}">
			<tr>
				<td>${i.bno}</td>
				<td>${i.btext}</td>
			</tr>
		</c:forEach>

	</table>

	<c:if test="${hasBlockPrev }">
		<a
			href="${cp }/guest/getSerchList?currentPage=${prevPage}&serchWord=${serchWord}">이전</a>
	</c:if>
	<c:forEach var="i" begin="${blockStartPage }" end="${blockEndPage }">

		
			<a
				href="${cp }/guest/getSerchList?currentPage=${i}&serchWord=${serchWord}">${i}</a>
		
	</c:forEach>

	<c:if test="${hasBlockNext}">
		<a
			href="${cp }/guest/getSerchList?currentPage=${nextPage}&serchWord=${serchWord}">다음</a>
	</c:if>

	<br>
	<br>
	<c:choose>
		<c:when test="${not empty serchWord  }">
			<form action="${cp }/guest/getSerchList">
				<input name="serchWord"> <input type="submit" value="검색">
			</form>
		</c:when>
		<c:when test="${empty serchWord }">
			<form action="${cp }/guest/getList">
				<input name="serchWord"> <input type="submit" value="검색">
			</form>
		</c:when>
	</c:choose>
	<!-- [ ] 글쓰기 페이지로 이동 -->
	<a href="${cp }/guest/write">새글 쓰기</a>

</body>
</html>