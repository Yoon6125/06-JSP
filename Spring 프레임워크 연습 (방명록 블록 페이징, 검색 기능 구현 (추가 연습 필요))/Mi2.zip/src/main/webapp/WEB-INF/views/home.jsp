<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<c:set var="cp" value="${pageContext.request.contextPath}" /><!-- el변수 cp에 경로저장 -->
<%@ page session="false" %>
<%@ page language="java" contentType="text/html; charset=UTF-8" 
	pageEncoding="UTF-8"%>
<html>
<head>
<meta charset="UTF-8">
<link rel="stylesheet" href="${cp }/resources/common.css" >
	<title>Home</title>
</head>
<body>
<h1>
	홈페이지
</h1>

<a href="${cp}/guest/getList">[방명록]</a>


</body>
</html>
