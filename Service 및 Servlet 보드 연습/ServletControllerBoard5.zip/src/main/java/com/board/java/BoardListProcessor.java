package com.board.java;

import com.daodtodata1.java.DAO;

public class BoardListProcessor {
	private DAO dao;
	public int totalPage = 0;
	public int currentPage = 0;

	public BoardListProcessor(DAO dao, String currentPage) {
		super();
		this.dao = dao;
		this.totalPage = totalPage;
		this.currentPage = Integer.parseInt(currentPage);
	}

}
