package com.board.java;

public class Board {
	static public final String DB_TABLE_NAME = "PS_BOARD_FREE";
}
