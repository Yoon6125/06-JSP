package com.daodtodata1.java;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.board.java.Board;

public class DAO extends DA {

	// 1. 글 삭제
	public void delete(String no) {
		connectDB();
		String sql = String.format("delete from %s where b_no ='%s'", Board.DB_TABLE_NAME, no);
		Updatesql(sql);
		closeConnect();
	}

	// 2. 글 작성
	public void write(DTO d) {
		connectDB();
		String sql = String.format("insert into %s (b_title , b_id , b_text) values (%s,%s,%s)", Board.DB_TABLE_NAME,
				d.title, d.id, d.text);
		Updatesql(sql);
		closeConnect();
	}
	// 3. 글 리스트

	public ArrayList<DTO> list() {
		ArrayList<DTO> post = null;
		connectDB();
		String sql = String.format("select * from %s", Board.DB_TABLE_NAME);
		try {
			ResultSet rs = st.executeQuery(sql);
			while (rs.next()) {
				post.add(new DTO(rs.getString("b_no"), rs.getString("b_title"), rs.getString("b_id"),
						rs.getString("b_datetime"), rs.getString("b_hit"), rs.getString("b_text"),
						rs.getString("b_reply_count"), rs.getString("b_reply_ori")));
			}
			closeConnect();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return post;
	}

	// 4. 글 수정
	public void edit(DTO d, String no) {
		connectDB();
		String sql = String.format("update %s set b_title ='%s' , b_text='%s' where b_no ='%s'", Board.DB_TABLE_NAME,
				d.title, d.text);
		Updatesql(sql);
		closeConnect();
	}

	// 5. 글 보기
	public DTO read(String no) {
		DTO d = null;
		connectDB();
		String sql = String.format("select * from %s where b_no ='%s'", Board.DB_TABLE_NAME, no);
		try {
			ResultSet rs = st.executeQuery(sql);
			while (rs.next()) {
				d = new DTO(rs.getString("b_no"), rs.getString("b_title"), rs.getString("b_id"),
						rs.getString("b_datetime"), rs.getString("b_hit"), rs.getString("b_text"),
						rs.getString("b_reply_count"), rs.getString("b_reply_ori"));
			}
			closeConnect();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return d;
	}
}
