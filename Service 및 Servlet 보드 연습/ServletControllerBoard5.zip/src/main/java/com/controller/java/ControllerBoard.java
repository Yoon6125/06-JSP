package com.controller.java;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.board.java.BoardListProcessor;
import com.daodtodata1.java.DTO;
import com.service.java.ServiceBoard;

@WebServlet("/board/*")
public class ControllerBoard extends HttpServlet {
	String nextPage;
	ServiceBoard service;

	@Override
	public void init() throws ServletException {
		service = new ServiceBoard();
	}

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String action = req.getPathInfo();
		if (action != null) {
			switch (action) {
			case "/del":
				nextPage = "/board/list";
				service.del(req.getParameter("no"));
				break;
			case "/write":
				nextPage = "/board/list";
				DTO d = new DTO(req.getParameter("title"), req.getParameter("id"), req.getParameter("text"));
				service.write(d);
				break;
			case "/edit_insert":
				nextPage = "/edit.jsp";
				req.setAttribute("post", service.read(req.getParameter("no")));
				break;
			case "/edit_proc":
				nextPage = "/board/list";
				service.edit(new DTO(req.getParameter("title"), req.getParameter("text")), req.getParameter("no"));
				break;
			case "/read":
				nextPage = "/read.jsp";
				DTO dto = service.read(req.getParameter("no"));
				req.setAttribute("post", dto);
				break;
			case "/list":
				nextPage = "/list.jsp";
				BoardListProcessor blp = service.list(req.getParameter("page"));
				req.setAttribute("blp", blp);
				break;
			}
			RequestDispatcher d = req.getRequestDispatcher(nextPage);
			d.forward(req, resp);
		}

	}
}
