package com.service.java;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.board.java.BoardListProcessor;
import com.daodto5.java.DTO;

@WebServlet("/board/*")
public class ServletController extends HttpServlet {
	String nextPage;
	Service service;

	@Override
	public void init() throws ServletException {
		service = new Service();
	}

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String action = req.getPathInfo();
		System.out.println("action:" + action);

		if (action != null) {
			switch (action) {
			case "/delete":
				System.out.println("삭제");
				nextPage = "/board/list";
				service.del(req.getParameter("no"));
				break;
			case "/write":
				System.out.println("쓰기");
				nextPage = "/board/list";
				DTO d = new DTO(req.getParameter("title"), req.getParameter("id"), req.getParameter("text"));
//				dao.write(d);
				service.write(d);
				break;
			case "/read":
				System.out.println("읽기");
				nextPage = "/read.jsp";
//				DTO dto = dao.read(req.getParameter("no"));
				DTO dto = service.read(req.getParameter("no"));
				req.setAttribute("post", dto);
				break;
			case "/list":
				System.out.println("리스트");
				nextPage = "/list.jsp";
//				ArrayList<DTO> post = dao.list();
				BoardListProcessor blp = service.list(req.getParameter("page"));
				req.setAttribute("blp", blp);
				break;

			case "/edit_datainsert":
				System.out.println("수정 데이터 입력");
				nextPage = "/edit.jsp";
				req.setAttribute("post", service.read(req.getParameter("no")));
				break;
			case "/edit_proc":
				System.out.println("데이터 수정사항 반영");
				nextPage = "/board/list";
				service.edit(new DTO(req.getParameter("title"), req.getParameter("text")), req.getParameter("no"));
				break;
			default:
				break;
			}
		}
		RequestDispatcher d = req.getRequestDispatcher(nextPage);
		d.forward(req, resp);

	}
}
