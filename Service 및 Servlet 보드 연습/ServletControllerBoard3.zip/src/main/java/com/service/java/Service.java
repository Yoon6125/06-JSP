package com.service.java;

import com.board.java.BoardListProcessor;
import com.daodto5.java.DAO;
import com.daodto5.java.DTO;

public class Service {
	DAO dao;

	public Service() {
		dao = new DAO();
	}

	public void del(String no) {
		dao.delete(no);
	}

	public void write(DTO d) {
		dao.write(d);
	}

	public DTO read(String no) {
		return dao.read(no);
	}

	public BoardListProcessor list(String currentPage) {
		if (currentPage == null) {
			currentPage = "1";
		}
		BoardListProcessor blp = new BoardListProcessor(dao, currentPage);
		return blp;
	}

	public void edit(DTO d, String no) {
		dao.edit(d, no);
	}

}
