package com.board.java;

public class Board {
	static public final int LIST_AMOUNT = 5;

	// table 이름
	public static final String SQL_TABLE = "PS_BOARD_FREE";
}
