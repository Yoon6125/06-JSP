package com.board.java;

import java.util.ArrayList;

import com.daodto5.java.DAO;
import com.daodto5.java.DTO;

public class BoardListProcessor {

	private DAO dao;
	public ArrayList<DTO> posts;
	public int totalPage = 0;
	public int currentPage = 0;

	public BoardListProcessor(DAO dao, String currentPage) {
		super();
		this.dao = dao;
		this.currentPage = Integer.parseInt(currentPage);
		this.totalPage = getPageCount();

		getList();
	}

	public void getList() {
		int startIndex = (currentPage - 1) * Board.LIST_AMOUNT; // 시작 인덱스 계산해서 dao.list 거쳐서 posts 로 보내기
		posts = dao.list(startIndex);
	}

	// 총 페이지 수 구하기
	public int getPageCount() {
		int Totalcount = 0;

		int count = dao.getPostCount();

		if (count % Board.LIST_AMOUNT == 0) {
			Totalcount = count / Board.LIST_AMOUNT;
		} else {
			Totalcount = count / Board.LIST_AMOUNT + 1;
		}

		return Totalcount;
	}

	// 총 페이지 수 구하기 (검색용)
	public int getSearchPageCount(String word) {
		int Totalcount = 0;

		int count = dao.getPostCount(word);

		if (count % Board.LIST_AMOUNT == 0) {
			Totalcount = count / Board.LIST_AMOUNT;
		} else {
			Totalcount = count / Board.LIST_AMOUNT + 1;
		}

		return Totalcount;
	}

	// 글 리스트 객체 얻는 함수
	public ArrayList<DTO> getPosts() {
		return posts;
	}

	// 페이지 리스트를 출력하기 위한 html 리턴
	public String getHtmlPageList() {
		String html = "";
		for (int i = 1; i <= totalPage; i++) {
			html = html + String.format("<a href='/board/list?page=%d'>%d</a>&nbsp;&nbsp", i, i);
		}
		return html;
	}

}
