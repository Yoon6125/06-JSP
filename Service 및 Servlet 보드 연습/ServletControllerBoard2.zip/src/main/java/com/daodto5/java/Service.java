package com.daodto5.java;

import java.util.ArrayList;

public class Service {
	DAO dao;

	public Service() {
		dao = new DAO();
	}

	public void del(String no) {
		dao.delete(no);
	}

	public void write(DTO d) {
		dao.write(d);
	}

	public DTO read(String no) {
		return dao.read(no);
	}

	public ArrayList<DTO> list() {
		return dao.list();
	}

	public void edit(DTO d, String no) {
		dao.edit(d, no);
	}

}
