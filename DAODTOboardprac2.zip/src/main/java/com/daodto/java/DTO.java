package com.daodto.java;

public class DTO {
	public String no;
	public String title;
	public String id;
	public String date_time;
	public String hit;
	public String text;
	public String reply_count;
	public String reply_ori;

	public DTO(String no, String title, String id, String date_time, String hit, String text, String reply_count,
			String reply_ori) {
		this.no = no;
		this.title = title;
		this.id = id;
		this.date_time = date_time;
		this.hit = hit;
		this.text = text;
		this.reply_count = reply_count;
		this.reply_ori = reply_ori;
	}

	public DTO(String title, String id, String date_time, String hit, String text, String reply_count,
			String reply_ori) {
		super();
		this.title = title;
		this.id = id;
		this.date_time = date_time;
		this.hit = hit;
		this.text = text;
		this.reply_count = reply_count;
		this.reply_ori = reply_ori;
	}

	public DTO(String no, String title, String id, String date_time, String hit) {
		super();
		this.no = no;
		this.title = title;
		this.id = id;
		this.date_time = date_time;
		this.hit = hit;
	}

}
