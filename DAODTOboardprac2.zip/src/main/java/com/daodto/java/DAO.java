package com.daodto.java;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class DAO {
	Connection con = null;
	Statement st = null;

	// 1. 글 목록

	public ArrayList<DTO> list() {
		ArrayList<DTO> post = new ArrayList<DTO>();

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/my_cat", "root", "root");
			st = con.createStatement();

			String sql = "select * from PS_BOARD_FREE";

			ResultSet rs = st.executeQuery(sql);

			while (rs.next()) {
				post.add(new DTO(rs.getString("b_no"), rs.getString("b_title"), rs.getString("b_id"),
						rs.getString("b_datetime"), rs.getString("b_hit")));
			}
			st.close();
			con.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

		return post;
	}

	// 2. 글 보기
	public DTO read(String a) {
		DTO post = null;

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/my_cat", "root", "root");
			st = con.createStatement();

			String sql = String.format("select * from  PS_BOARD_FREE where b_no='%s'", a);
			ResultSet rs = st.executeQuery(sql);
			while (rs.next()) {
				post = new DTO(rs.getString("b_no"), rs.getString("b_title"), rs.getString("b_id"),
						rs.getString("b_datetime"), rs.getString("b_hit"), rs.getString("b_text"),
						rs.getString("b_reply_count"), rs.getString("b_reply_ori"));
			}

			st.close();
			con.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

		return post;
	}

	// 3. 글 작성

	// 4. 글 삭제
	public void delete(String a) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/my_cat", "root", "root");
			st = con.createStatement();

			String sql = String.format("delete from PS_BOARD_FREE where b_no ='%s' ", a);

			int result = st.executeUpdate(sql);

			System.out.println("실행된 쿼리:" + sql);
			System.out.println("실행된 행 수:" + result);

			st.close();
			con.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	// 5. 글 수정
}
